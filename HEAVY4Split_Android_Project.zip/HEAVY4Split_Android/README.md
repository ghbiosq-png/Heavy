# HEAVY 4-SPLIT Android 앱 프로젝트

## 설치 APK 만들기
1. PC에서 Android Studio를 설치합니다.
2. 이 프로젝트 폴더를 Android Studio에서 **Open** 합니다.
3. Gradle Sync 후 `Build > Build Bundle(s) / APK(s) > Build APK(s)`를 선택합니다.
4. `app/build/outputs/apk/debug/app-debug.apk`를 휴대폰으로 복사해 설치합니다.

이 파일은 **APK가 아니라 Android Studio 프로젝트**입니다. Android SDK/Gradle이 없는 환경에서 APK를 빌드하지 않았습니다.

## 변경사항
- 새 세션 생성 시 휴대폰 시스템 날짜 사용. 이전 세션은 보존하고 과거 날짜인 경우 안내 표시.
- 완료 시 세션 날짜가 오늘과 다르면 확인 후 오늘 날짜로 저장.
- 하체 A의 레그프레스를 싱글 레그프레스로 변경, 왼쪽/오른쪽 각각 입력 및 완료 체크. 새 세션 기본값 32kg/40kg 좌우 2세트.
- 기존 운동/기록/워밍업/JSON 백업 유지. 기존 JSON 가져오기 가능.
- JSON/TXT 저장은 안드로이드 시스템 파일 저장 창 사용.

## 중요
- 데이터는 이 앱의 WebView 로컬 저장소에 저장됩니다. 기존 브라우저 저장소와 **자동으로 공유되지 않습니다**.
- 설치 후 **백업 불러오기**로 제공된 JSON을 가져오세요.
- 주기적으로 백업 JSON을 저장하세요. 앱 데이터 삭제/재설치 시 데이터가 사라질 수 있습니다.
- 기존 JSON의 완료 기록은 원본 그대로 남고 새 세션에만 새 싱글 레그프레스 구성이 적용됩니다.
