package kr.heavy.foursplit;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.*;
import android.widget.Toast;
import android.view.View;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
 private static final int IMPORT_FILE=1001, SAVE_FILE=1002;
 private WebView web;
 private ValueCallback<Uri[]> uploadCallback;
 private String pendingContents="";
 @Override public void onCreate(Bundle state){super.onCreate(state);
  web=new WebView(this);setContentView(web);
  web.getSettings().setJavaScriptEnabled(true);
  web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowFileAccess(true);
  web.getSettings().setDefaultTextEncodingName("UTF-8");
  web.addJavascriptInterface(new Bridge(),"AndroidBridge");
  web.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params){
    if(uploadCallback!=null)uploadCallback.onReceiveValue(null);
    uploadCallback=cb;
    Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");startActivityForResult(intent,IMPORT_FILE);return true;
   }
  });
  web.loadUrl("file:///android_asset/index.html");
 }
 public class Bridge {
  @JavascriptInterface public void saveFile(String filename,String contents,String mime){
   runOnUiThread(()->{pendingContents=contents;Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
    intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(mime.split(";")[0]);intent.putExtra(Intent.EXTRA_TITLE,filename);
    startActivityForResult(intent,SAVE_FILE);
   });
  }
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
  if(request==IMPORT_FILE){if(uploadCallback!=null){uploadCallback.onReceiveValue(result==RESULT_OK&&data!=null?new Uri[]{data.getData()}:null);uploadCallback=null;}return;}
  if(request==SAVE_FILE&&result==RESULT_OK&&data!=null){try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
   if(out!=null){out.write(pendingContents.getBytes(StandardCharsets.UTF_8));Toast.makeText(this,"파일 저장 완료",Toast.LENGTH_SHORT).show();}
  }catch(Exception e){Toast.makeText(this,"저장 실패: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
 }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
